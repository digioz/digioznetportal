﻿using System;
using System.Collections.Generic;

namespace digiozPortal.BO
{
    public partial class Zone
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ZoneType { get; set; }
    }
}
