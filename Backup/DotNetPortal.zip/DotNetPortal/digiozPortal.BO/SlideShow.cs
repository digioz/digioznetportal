﻿using System;
using System.Collections.Generic;

namespace digiozPortal.BO
{
    public partial class SlideShow
    {
        public int Id { get; set; }
        public string Image { get; set; }
        public string Description { get; set; }
    }
}
