﻿using System;
using System.Collections.Generic;

namespace digiozPortal.BO
{
    public partial class CommentLike
    {
        public string Id { get; set; }
        public string UserId { get; set; }
        public string CommentId { get; set; }
    }
}
