﻿using System;
using System.Collections.Generic;

#nullable disable

namespace digioz.Portal.Bo
{
    public partial class PollVote
    {
        public string Id { get; set; }
        public string UserId { get; set; }
        public string PollAnswerId { get; set; }
    }
}
