﻿using System;
using System.Collections.Generic;

#nullable disable

namespace digioz.Portal.Bo
{
    public partial class Zone
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ZoneType { get; set; }
    }
}
