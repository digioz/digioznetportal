﻿using System;
using System.Collections.Generic;

#nullable disable

namespace digioz.Portal.Bo
{
    public partial class PollAnswer
    {
        public string Id { get; set; }
        public string PollId { get; set; }
        public string Answer { get; set; }
    }
}
