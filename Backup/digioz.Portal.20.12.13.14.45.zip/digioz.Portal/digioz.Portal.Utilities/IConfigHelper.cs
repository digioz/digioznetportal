﻿using System;
using System.Collections.Generic;
using System.Text;

namespace digioz.Portal.Utilities
{
    public interface IConfigHelper
    {
        string GetConnectionString();
    }
}
