﻿using System;

namespace digioz.Portal.Payment
{
    public class Class1
    {
    }
}
